@echo off
title TAI - Install Requirements
echo Installing required Python package (requests)...
pip install requests
if errorlevel 1 (
  echo.
  echo ERROR: pip not found. Is Python installed with "Add to PATH" ticked?
)
echo.
pause
